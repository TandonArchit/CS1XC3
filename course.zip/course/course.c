/**
 * @file course.c
 * @author Archit Tandon
 * @version 0.1
 * 
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief The enroll_student function dynamically allocates space for a new student and thus enrolls them
 * 
 * @param course 
 * @param student 
 * @return nothing
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    // Since there is just one student, we can just assign the space for 1 student with calloc (initialized to 0)
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    // Since there are students before this one, we will use the realloc fucntion to re-allocate more space
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief The print_course function prints all the information in a properly formatted way
 * 
 * @param course 
 * @return nothing
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // A for loop is used here to print students as there can be more than 1.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief The top_student function gives us the highest scoring student by searching for it using a sorting algorithm
 * 
 * @param course 
 * @return Student* 
 */

Student* top_student(Course* course)
{
  // First case, no students returns NULL
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  // Main for loop that iterates the same number of times as there are students in the course
  for (int i = 1; i < course->total_students; i++)
  {
    // A temporary variable holds the score and replaces it if a higher one is found, thus leaving us the max
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief The passing function tells us the students and the number of students in a course that score more than 50, that is, the ones that pass
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  // Counting the number of students that pass
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  // Dynamically allocating space for storing the students that pass
  // The size is set to the number of students that pass and not the total in the course
  // Calloc is used and it initializes to 0
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    // If a student passes, we store them in passing
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}