/**
 * @file student.h
 * @author Archit Tandon
 * @version 0.1
 * 
 */

/**
 * @brief Defining the type student
 * 
 */

typedef struct _student 
{ 
  char first_name[50]; /**< Student's first name */
  char last_name[50]; /**< Student's last name */
  char id[11]; /**< Student's ID*/
  double *grades; /**< All of the student's grades*/
  int num_grades; /**< Total number of grades for for the student*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
