/**
 * @file main.c
 * @author Archit Tandon
 * @version 0.1
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief The main function in main.c
 * 
 * @return int 
 */

int main()
{
  srand((unsigned) time(NULL));
  // Using calloc to dynamically allocate space for MATH101
  Course *MATH101 = calloc(1, sizeof(Course));
  // Using strcpy function to set the name and course code for MATH101
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
  // Randomlly enrolling students in the MATH101 course with the enroll_student function
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  // Using the top_student function to determine who scored the most and assigning them to 'student'
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  // Using the passing_students function to calculate the number of students passing the course by scoring more than 50
  // and an array of all the students the pass
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}