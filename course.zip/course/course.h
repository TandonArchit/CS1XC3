/**
 * @file course.h
 * @author Archit Tandon
 * @version 0.1
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Defining the type course 
 * 
 */
 
typedef struct _course 
{
  char name[100]; /**< Name of the course*/
  char code[10]; /**< Course code or identifier*/
  Student *students; 
  int total_students; /**< Total number of students in the course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


