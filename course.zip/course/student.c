/**
 * @file student.c
 * @author Archit Tandon
 * @version 0.1
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief The add_grade function adds a new grade to a student's data
 * 
 * @param student 
 * @param grade 
 * @return nothing
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // Calloc is used to dynamically assign the space of one double if num_grades for the student is one
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    // Realloc is used to re-assign more space to the students grades to store the new grade
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief The average function is used to calculate the average score of a particular student
 * 
 * @param student 
 * @return double 
 */

double average(Student* student)
{
  // First case, if there are no grades in record, the average can be returned as 0
  if (student->num_grades == 0) return 0;

  double total = 0;
  // Using a for loop to go through all the grades of the student and adding them all up in the 'total'
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  // Calculating and then returning the average by dividing the total by the number of grades there were
  return total / ((double) student->num_grades);
}

/**
 * @brief The print_student fucntion prints out all the information about a student in a proper format
 * 
 * @param student 
 * @return nothing
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // A for loop goes through all the grades in the student's record
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief The generate_random_student function randomlly picks all the data for a student and thus effectively generates a new random student
 * 
 * @param grades 
 * @return Student* 
 */

Student* generate_random_student(int grades)
{
  // A set of some first and last names for the function to later pick from
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  // Calloc is used to dynamically assign space for a student 
  Student *new_student = calloc(1, sizeof(Student));

  // The strcpy function is used to assign the first and the last name to the recently generated new_student
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Two for loops are used, first to assign the ID and then to assign random grades to the student

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}