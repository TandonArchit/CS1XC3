var searchData=
[
  ['add_5fgrade_0',['add_grade',['../student_8c.html#a1ee4302d01d8908db57e238f5f9dd9f5',1,'add_grade(Student *student, double grade):&#160;student.c'],['../student_8h.html#a1ee4302d01d8908db57e238f5f9dd9f5',1,'add_grade(Student *student, double grade):&#160;student.c']]],
  ['average_1',['average',['../student_8c.html#a3efb000301e4e0c8e68930bc93e0958e',1,'average(Student *student):&#160;student.c'],['../student_8h.html#a3efb000301e4e0c8e68930bc93e0958e',1,'average(Student *student):&#160;student.c']]]
];
